import 'reflect-metadata';
import * as express from 'express';
import * as bodyParser from 'body-parser';
import * as cors from 'cors';
import { corsClientHost, serviceConfig } from './config';
import { Container } from 'typedi';
import { HTTP_SERVER_TOKEN } from './constants';
import { createProxyMiddleware } from 'http-proxy-middleware';
import LogService from '@hds/edge-sdk';
import { EWEdgeSdkService } from './services/edge-sdk.service';
import { Server as HttpServer } from 'http';
import { DataCustomService } from './services/Data-Custom.service';
import {OilBurnerService} from './services/oil-burner.service';

export class Server {
  public app: express.Application;

  constructor() {
    this.app = express();   

    this.createMiddlewares();
  }
  public setHttpServerToken(httpServer: HttpServer): void {
    /**
     * Add http server to Inversion-of-Control's (IoC) container.
     * Will need it later for websocket client.
     *
     * Side note: in this DEMO middleware IoC is implemented using 3rd-party npm package "typedi"
     */
    Container.set(HTTP_SERVER_TOKEN, httpServer);
  }

  public createsubscriptionRouter() {  
   
    const edgeSdk = Container.get(EWEdgeSdkService);
    //console.log(edgeSdk._subscriptionRouter.router);
   
    // const testData = {
    //   name: 'John Doe',
    //   age: '30',
    //   account_balance: '15.5'
    // }
  //   this.app.get('/', (req, res) => res.send(testData));
  //  this. app.post('/book', (req, res) => {
  //     // We will be coding here
      
     
  //     res.send(testData)
  // });
//   this.app.use('/api/v1/subscription/:id', (req,res)=> {
//     //this.iorr.displayOilBurner("SWT_OilLine1","SWT_OilSG","OILSG");
//     res.send(testData);
//  });
 
  this.app.use('/api/v1/subscription/', edgeSdk._subscriptionRouter.router); //localhost:3000/api/v1/subscription/
 this.app.use('/api/v1/data/', edgeSdk._dataRouter.router);
  //console.log("subscription");
    
  
    // this.app.use(
    //     '/',
    //     createProxyMiddleware({
    //       target: serviceConfig.appUIUrl,
    //       changeOrigin: true,
    //     })
    //   );
  }
  public handleDatacoustomover(): void {
    const dataService = Container.get(DataCustomService);
    dataService.handleCrossover();
  }
  public createMiddlewares() {
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: false }));
  }

}
export default new Server();