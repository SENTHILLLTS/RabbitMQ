cd /src \
&& curl -s -u${CI_USR}:${CI_PSW} ${ARTIFACTORY_NPM}/auth -o ~/.npmrc \
&& npm config set registry ${NPM_REGISTRY} \
&& npm install \
&& npm run build_libs \
&& /scripts/publish-lib-tag.sh ${DEV_BRANCH} /src/dist/demo-infocard-widget-lib \
&& /scripts/publish-lib-tag.sh ${DEV_BRANCH} /src/dist/demo-input-table-widget-lib 